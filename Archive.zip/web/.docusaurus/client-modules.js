export default [
  require("/Users/pau1tuck/dev/projects/algobeast-v4/web/node_modules/infima/dist/css/default/default.css"),
  require("/Users/pau1tuck/dev/projects/algobeast-v4/web/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/Users/pau1tuck/dev/projects/algobeast-v4/web/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/Users/pau1tuck/dev/projects/algobeast-v4/web/src/theme/styles/custom.css"),
  require("/Users/pau1tuck/dev/projects/algobeast-v4/web/src/theme/styles/fonts.css"),
];
