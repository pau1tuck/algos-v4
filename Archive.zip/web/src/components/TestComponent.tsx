// src/components/TestComponent.tsx
import React from "react";
import { RootState } from "@site/src/redux/store"; // Adjust path

const TestComponent: React.FC = () => {
    return <div>Hello, Dog.</div>;
};

export default TestComponent;
